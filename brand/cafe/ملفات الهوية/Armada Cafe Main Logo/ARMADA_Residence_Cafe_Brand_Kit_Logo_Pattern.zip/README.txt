ARMADA RESIDENCE — Café & Restaurant · Brand Kit 2026

logo/png    — master artwork in approved colourways (transparent + on-field), 3488 px wide
logo/svg    — SVG containers carrying the master raster untouched (NOT traced or redrawn). True vector requires the original source file.
pattern/svg — Armada Arc Pattern, true vector (quarter-circle module, 120 px grid)
pattern/png — 3840 px exports of the same

Palette: Porcelain #F3E9DB · Oxblood #6C1F33 · Espresso #211817 · Rose #C58A91 · Bronze #A97C50
Rules: full lockup only · 1X clear space · pattern never under the logo · max two colours per pattern field

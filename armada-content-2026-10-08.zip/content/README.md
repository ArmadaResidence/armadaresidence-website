# /content/ — source of truth for the new armadaresidence.com

Updated 8 Oct 2026 with reception/management answers (prices, sizes, beds, addresses, phones,
emails, check-in/out, cancellation, breakfast, hall, legal entity). Any value still marked
`[يُؤكَّد]` must be replaced before build; `qa.py` fails on it.

| File | What it holds | Status |
|---|---|---|
| branches.json | both properties, national addresses, phones, WhatsApp, coordinates, new descriptions | verified; unit counts unconfirmed (hidden) |
| rooms.json | 12 room types — prices incl. VAT, sizes, capacity, beds, kitchen/balcony/jacuzzi flags | verified; in-room amenities + new descriptions pending |
| pricing.json | site-wide price rules: "from" display, breakfast 20, extra person 25, included guests | verified |
| policies.json | check-in 16:00 / check-out 12:00, cancellation (24h, matches Booking.com) | verified; refund + privacy text pending |
| legal.json | legal name, CR, VAT number, national addresses, footer line | verified; address proofs expired 17/4/2026 |
| contact.json | per-branch phones/WhatsApp, sales line, emails, notification inboxes, social, GTM, menu | verified; sales email, YouTube, GBP pending |
| offers.json | groups/B2B quote-on-request line (Umrah 50% offer removed) | verified |
| halls.json | Airport Road hall, 50 pax, pricing via sales (phase 2 page) | verified; feature list pending |
| seo.json | per-page titles, descriptions, JSON-LD types, noindex flags | draft 1 |
| site-texts.json | slogan, hero, "About", "Why Armada" — new copy draft 1 | awaiting Ahmed's approval |
| images.json | 116 legacy gallery URLs by branch | reference only — all photos to be replaced |
| legacy-texts.json | old hero/about/nav/blog claims | reference only — do not reuse |

Rules carried into the data:
- Prices are board rates: per night, room only, incl. VAT, same all week on the site, shown as «يبدأ من / from».
- Accessible rooms (both branches) are `active: false`, `show_on_site: false` — can be enabled later.
- Airport Road = شقق فندقية. Never شقق مخدومة.
- Room slugs repeat across branches on purpose (`airport-road/king-room`, `shafa-road/king-room`).

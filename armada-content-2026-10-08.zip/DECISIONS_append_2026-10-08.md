# DECISIONS.md — entries to append (8 Oct 2026)

## 2026-10-08 — Pricing display
- Website prices = board rates: per night, room only, incl. VAT. Same price all week on the site.
- Displayed as «يبدأ من … ريال / الليلة — شامل الضريبة» because the internal sales policy varies by day and is reviewed daily.
- Breakfast is an optional add-on: 20 SAR/person/day. Extra person: 25 SAR/night. 20 SAR deducted per guest below the included count (2, or 4 in two-bedroom suites).
- Three pricing phases: (1) now — `starting_from`, reception confirms final price on booking; (2) admin rate calendar — reception sets price per day per room type, site reads it; (3) channel manager syncs rates/availability with Booking.com and others — «يبدأ من» dropped, real price per date shown.
- Data model from day one: `rooms.json` → `base_price` + `currency` + `pricing_mode` (`starting_from` | `calendar`); Supabase `rates` = one row per day per room type. No restructuring later.
- Source: sales & pricing policy, Oct 2026.

## 2026-10-08 — Check-in / check-out
- Check-in 16:00, check-out 12:00, both branches. (Replaces the unverified 15:00 in the old contact.json.)

## 2026-10-08 — Cancellation policy (final wording)
- Free cancellation up to 24 h before arrival. Same-day cancellation or no-show: first night charged. Both branches. Must match Booking.com word for word.

## 2026-10-08 — Offers
- Umrah 1448 "50%" offer removed: no current offer. Offers page carries one quote-on-request line: «أسعار خاصة لشركات العمرة والمجموعات» via sales 053 662 2288.

## 2026-10-08 — Contact routing
- Per-branch phone = WhatsApp: Airport Road +966 53 662 2277, Shafa Road +966 53 666 3030.
- Sales line +966 53 662 2288: groups, hall, B2B only — not shown as a general reservations number.
- Booking-request notifications go to reservation@armadaresidence.com and info@armadaresidence.com.

## 2026-10-08 — Rooms
- Accessible rooms in both branches are shown as «غير متاح حاليًا» (sold out), 185 SAR, no booking CTA — not hidden. Shafa legacy price 450 was a typo.
- Confirmed features: fridge in all Airport Road rooms; kettle in all rooms both branches; kitchen only in Airport Road suites; no in-room washers (central laundry).
- Breakfast: daily buffet, modelled on the rate plan (`room_only` / `bed_and_breakfast`), never on the room. Daily buffet at both branches, SAR 20 per person per day. Phase 1 shows the room-only plan with breakfast as an add-on; the bed_and_breakfast plan is modelled but hidden until phase 2. Shown as «بوفيه إفطار يومي» in Why Armada and on branch pages.
- Airport Road one-bedroom suite bed type is king (legacy "king or twin on request" dropped).
- Shafa two-bedroom jacuzzi suite is 45 m² with no living room — the description must say so.
- Kitchens: Airport Road suites only. No washing machines anywhere. Balcony: Shafa "Room with Balcony" only.

## 2026-10-08 — Legal
- Entity: شركة أرمادا ريزيدنس لتشغيل الفنادق / Armada Residence Company To Operate Hotels — CR 1010874796 (main, Riyadh) — VAT 312154414400003. Lives in content/legal.json; footer line defined there.
- National-address proofs expired 17 Apr 2026 → renew before Tap Payments and Google Business submissions.

## 2026-10-08 — Content structure
- New files: pricing.json, policies.json, legal.json, site-texts.json. Legal fields removed from contact.json.
- Unit counts (108 / 32) are not shown on the site until confirmed.

## 2026-10-08 — Policies page & SEO
- /policies content lives in `content/policies.json → page.sections` (booking, check-in/out, cancellation, guests & breakfast, payment & refunds, privacy, operator). Payment section carries a phase-3 bracket for online payment/refunds; refund window still [يُؤكَّد].
- Per-page titles/descriptions live in `content/seo.json`; accessible-room pages are `noindex` while sold out.
- House rules (8 Oct): ID from the booking holder only at check-in; all rooms non-smoking; children free under an age still to be given.
- Policies page carries key terms from the in-house stay agreement (8 Oct): SAR 300 refundable deposit, late check-out SAR 100 until 14:00 / SAR 200 until 16:00, key-card loss SAR 10, no unregistered guests, no pets, non-smoking rooms. Children's breakfast: ≤5 free, 6–12 half price, 13+ adult.
- Children (8 Oct): not counted in included guests; extra-person and breakfast fees by age — ≤5 free, 6–12 half, 13+ adult. SAR 300 deposit stays in the in-house agreement only, not on the site. Online refunds (phase 3): same method, 5–14 business days.
